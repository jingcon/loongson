#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCharts>
QT_CHARTS_USE_NAMESPACE
#include "mqtt/qmqtt.h"	//添加mqtt头文件
#include <QtNetwork/QtNetwork>
#include <QtNetwork/QHostAddress>
#include <QString>
#include <QTcpServer> //负责连接
#include <QTcpSocket> //负责数据收发
#include <QTimer>




#include <QNetworkReply>
#include <QNetworkAccessManager>
#include <QSslSocket>
#include <QSslCertificate>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:

    void doConnected();

private slots:


    void new_client();
    void new_client1();
    void new_client2();

    void read_data();
    void read_data1();
    void read_data2();
    void on_pushButton_2_clicked();
    void onTimeout();
    void  onTimeout1();
    void  onTimeout2();
    void  onTimeout3();
    void on_pushButton_clicked();



private:
        Ui::MainWindow *ui;
        QMQTT::Client *mqtt_client;
       QString m_strProductKey,m_strDeviceName,m_strDeviceSecret,m_strHostName,m_strRegionId,m_strPubTopic,m_strSubTopic,message,message1;
       QByteArray msgg0,msgg1,msgg2;

       QByteArray msg;
       QTcpServer *server;
       QTcpServer *server1;
       QTcpServer *server2;
       QTcpSocket *socket;
       QTcpSocket *socket1;
        QTcpSocket *socket2;
       //uint8_t buff1[100];
       QString buff1;

       QSplineSeries *series;
        QChart *chart;
        QList<QPointF> list;      //存放点数据的链表
        uint64_t num;
        QSplineSeries *series_0;
         //QChart *chart;
         QList<QPointF> list_0;      //存放点数据的链表
         uint64_t num_0;

       QSplineSeries *series1;
        QChart *chart1;
        QList<QPointF> list1;      //存放点数据的链表
        uint64_t num1;

       QSplineSeries *series2;
        QChart *chart2;
        QList<QPointF> list2;      //存放点数据的链表
        uint64_t num2;

public:
    int msg_int,msg_int1,msg_int2;

    int msg_tem,msg_humi,msg_light;
    int msg_v1,msg_v2,msg_v3;
    float msg_float,msg_mq5;
    uint64_t i_count;
    QTimer *timer1;
    QTimer *timer2;
    QTimer *timer3;
    int i1,i2,i3;//节点1的i1++计数

     QString fileName1;
     QString fileName2;
     QString fileName3;

     QDateTime dateTime;


     int msg_disv1,msg_disv2,msg_disv3;

      QString webhookUrl;

};
#endif // MAINWINDOW_H
